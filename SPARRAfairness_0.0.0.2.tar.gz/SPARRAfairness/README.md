## SPARRAfairness: an R package implementing functions for assessing differential behaviour of the SPARRA score in demographic groups.

To download and install this package, use

```
install.packages("SPARRAfairness")
library(SPARRAfairness)
```

For examples demonstrating use of this package, see vignette ```SPARRAfairness_vignette```.
