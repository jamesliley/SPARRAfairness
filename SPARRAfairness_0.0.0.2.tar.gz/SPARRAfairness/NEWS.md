# News for package SPARRAfairness

# SPARRAfairness version 0.1.0

The manuscript corresponding to this package will be published on arXiv.
