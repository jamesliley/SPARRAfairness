# News for package SPARRAfairness

# SPARRAfairness version 0.0.2

The manuscript corresponding to this package is available at https://www.medrxiv.org/content/10.1101/2024.02.13.24302753v1 and will be published in PLoS Digital Health.

This version of the package now uses ggplot2 to draw several figures, using a more conventional style than the previous version.
